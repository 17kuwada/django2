from django.contrib import messages
from django.views import generic
from django.urls import reverse_lazy
from django.views.generic import TemplateView

from .forms import InquiryForm

# お問い合わせ送信内容をログに残す
import logging
logging = logging.getLogger(__name__)

# 'アプリ名:url名'からURLを取り出す

# ページ間でメッセージを送る機能

# Create your views here.
# ここにクラスを登録することによりアプリ内の画面を登録する

#   IndexViewクラスはindex.htmlを元にページを構成する

class IndexView(generic.TemplateView):
    template_name = 'index.html'

# お問い合わせページ
class InquiryView(generic.FormView):
    template_name = 'inquiry.html'
    form_class = InquiryForm
    success_url = reverse_lazy('diary:index')


    def form_valid(self, form):
        form.send_mail()
        messages.success(self.request, 'メッセージを送信しました')
        messages.success(self.request, 'CCでメールを同報しています')
        messages.success(self.request, 'ご確認下さいませ')
        logging.info(f'Inquiry sent by {form.cleaned_data['name']}')
        return super().form_valid(form)
    

from django.contrib.auth.mixins import LoginRequiredMixin
from .models import Diary

# 日記一覧
# ログインが必要で尚且つ一覧表示するViewを継承する
class DiaryListView(LoginRequiredMixin,generic.ListView):
    model = Diary
    template_name = 'diary_list.html'
    paginate_by=2

    # 問い合わせ条件を設定する
    # ※今回は全行ではなくログインしている人の日記のみが対象となる
    def get_queryset(self):
        # Diaryテーブルから条件に当てはまる行を抽出する
        diaries = Diary.objects.filter(use=self.request.user)
        return diaries
        # return super().get_queryset()