from .settings_common import *

EMAIL_BACKEND = 'django.core.mail.backends.console.EmailBackend'

